function Item1(props) {   
  return (
    <p>
      Maçã
    </p>
  )
}

export function Item2(props) {
  return (
      <p>
        Banana
      </p>
  )
}

export function Item3(props) {
   return(
    <p>
        Laranja
    </p>
    )
}

export default Item1;