import {Item2, Item3} from "./Item";

function Lista(props) {  
  return (
      <>
      <ul>
        Lista de compras:
        <li>
            
        </li>
        <li>
            <Item2/>
        </li>
        <li>
            <Item3/>
        </li>
      </ul>
      </>
  )
}

export default Lista;